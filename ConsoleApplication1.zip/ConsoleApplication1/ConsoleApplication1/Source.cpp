//header files used
#include<iostream>
#include <stdlib.h>
#include<stdio.h>
#include <fstream> 
#include <string> 
using namespace std;

//Indicates a single unit of meeting room
struct Room
{
	int isTicked = 0;//indicates room is occupied or not
	int surrRoomCount = 0;//indicates occupied surrounding room count.Max can be 4
};

//class for handling allocation of rooms inside a room container
class RoomContainer
{
private:
	int m_Row;//total count of rows in a room container
	int m_Column;//total count of columns in a room container
	int m_point;//o/p of the program or overlapping room count
	int m_lowestSurroundCount;//rooms will be occupied based on this count for each cycle of allocation
	int m_roomallocationcount;//Total number of meeting rooms required

	int* m_surroundCountArray;//This pointer is used to hold surrounding count of each non-occupied room
	Room** Room2DArray;//This pointer is used to acesss each meeting room in the container

public:
	RoomContainer(int ROW, int COLUMN);//Row and columns are captured during container creation
	void init();//Initialising member variables and Room2DArray
	void initialiseZerovalue();//Initialise surrounding count and isticked with zero
	void AllocateRooms(int allocationNumber);//Master method for allocating meeting rooms
	void displayPoint();//This one will print the o/p
	void processIstickedLogic(int i, int j);//room is allocated by making the isticked value to 1
	void informNeighbours(int i, int j);//inform the neighbouring rooms and increment the surrRoomCount by 1.
	void findTheleastDisturbed();//Rooms will be allocated for the least disturbed items
	int AllocationLogic(int init_Row, int init_Column);
	~RoomContainer()
	{
		free(m_surroundCountArray);
		free(Room2DArray);
	}
};
//constructor definition
RoomContainer::RoomContainer(int ROW, int COLUMN)
{
	m_Row = ROW;
	m_Column = COLUMN;
	init();
}
//Initialisation and it is getting called defaultly from constructor
void RoomContainer::init()
{
	m_lowestSurroundCount = 0;
	m_point = 0;
	m_roomallocationcount = 0;
	Room2DArray = (Room * *)malloc(m_Row * sizeof(Room*));
	for (int i = 0; i < m_Row; i++)
		Room2DArray[i] = (Room*)malloc(m_Column * sizeof(Room));
	initialiseZerovalue();
}
//Initialise the array with zero value
void RoomContainer::initialiseZerovalue()
{
	for (int i = 0; i < m_Row; i++)
	{
		for (int j = 0; j < m_Column; j++)
		{
			Room2DArray[i][j].surrRoomCount = 0;
			Room2DArray[i][j].isTicked = 0;
		}
	}
}
//allocation of meeting room w.r.t parameter allocationnumber
void RoomContainer::AllocateRooms(int allocationNumber)
{
	m_roomallocationcount = allocationNumber;
	int init_Row, init_Column;
	if (((m_Row > 2) && (m_Row % 2 == 1)) &&
		((m_Column > 2) && (m_Column % 2 == 1)))
	{
		//This is for handling a special case like middle room need to be occupied first for below condition.
		//For e.g ROW = 3 && COLUMN = 5
		//This logic try to allocate twice and after that least disturbed point value will get returned
		int poitValueLogic1, poitValueLogic2;
		init_Row = m_Row / 2;
		init_Column = m_Column / 2;
		m_roomallocationcount = allocationNumber;
		poitValueLogic1 = AllocationLogic(init_Row, init_Column);
		init_Row = 0;
		init_Column = 0;
		m_roomallocationcount = allocationNumber;
		initialiseZerovalue();
		m_lowestSurroundCount = 0;
		m_point = 0;
		poitValueLogic2 = AllocationLogic(init_Row, init_Column);
		if (poitValueLogic1 > poitValueLogic2)
		{
			m_point = poitValueLogic2;
		}
		else
		{
			m_point = poitValueLogic1;
		}
	}
	else
	{
		//All other cases will be enter here
		init_Row = 0;
		init_Column = 0;
		AllocationLogic(init_Row, init_Column);
	}
}
//This method is responsible for allocating rooms inside a meeting hall
//Rooms will be allocated in each cycle w.r.t to the least surrounding count in a cycle
int RoomContainer::AllocationLogic(int init_Row, int init_Column)
{
	int i = 0, j = 0;
	while (m_roomallocationcount > 0)
	{
		for (i = init_Row; i < m_Row; i++)
		{
			for (j = init_Column; j < m_Column; j++)
			{
				if (i == 0 && j == 0 && Room2DArray[i][j].isTicked == 0)
				{
					Room2DArray[i][j].surrRoomCount = 0;
					Room2DArray[i][j].isTicked = 1;
					//inform neighbouring rooms and setting their surrounding count
					informNeighbours(i, j);
					m_roomallocationcount--;
					if (m_roomallocationcount == 0)
					{
						break;
					}
				}
				else
				{
					processIstickedLogic(i, j);
					if (m_roomallocationcount == 0)
					{
						break;
					}
				}
				init_Column = 0;
			}
			if (m_roomallocationcount == 0)
			{
				break;
			}
			init_Row = 0;
		}
		if (m_roomallocationcount == 0)
		{
			break;
		}
		findTheleastDisturbed();
		init_Row = 0; init_Column = 0;
	}
	return m_point;
}
//This method will get called in each cycle before room allocation starts
//Rooms will be allocated for the least disturbed items
void RoomContainer::findTheleastDisturbed()
{
	m_surroundCountArray = (int*)malloc((m_Column * m_Row) * sizeof(int));
	int index = 0;
	for (int i = 0; i < m_Row; i++)
	{
		for (int j = 0; j < m_Column; j++)
		{
			if (Room2DArray[i][j].isTicked == 0)
			{
				m_surroundCountArray[index] = Room2DArray[i][j].surrRoomCount;
				index++;
			}
		}
	}
	m_lowestSurroundCount = m_surroundCountArray[0];
	for (int i = 0; i < index; i++)
	{
		if (m_lowestSurroundCount > m_surroundCountArray[i])
		{
			m_lowestSurroundCount = m_surroundCountArray[i];
		}
	}

}
//When a room is allocated this method will call and inform the neighbouring rooms and increment the
//surrRoomCount by 1.
void RoomContainer::informNeighbours(int i, int j)
{
	if (j - 1 >= 0)
	{
		Room2DArray[i][j - 1].surrRoomCount = Room2DArray[i][j - 1].surrRoomCount + 1;
	}
	if (i - 1 >= 0)
	{
		Room2DArray[i - 1][j].surrRoomCount = Room2DArray[i - 1][j].surrRoomCount + 1;
	}
	if (j + 1 < m_Column)
	{
		Room2DArray[i][j + 1].surrRoomCount = Room2DArray[i][j + 1].surrRoomCount + 1;
	}
	if (i + 1 < m_Row)
	{
		Room2DArray[i + 1][j].surrRoomCount = Room2DArray[i + 1][j].surrRoomCount + 1;
	}
}
//room is allocated by making the isticked value to 1
void RoomContainer::processIstickedLogic(int i, int j)
{
	int counter = 0;
	if (j - 1 >= 0)
	{
		if (Room2DArray[i][j - 1].isTicked == 1)
		{
			counter++;
		}
	}
	if (i - 1 >= 0)
	{
		if (Room2DArray[i - 1][j].isTicked == 1)
		{
			counter++;
		}
	}
	if (j + 1 < m_Column)
	{
		if (Room2DArray[i][j + 1].isTicked == 1)
		{
			counter++;
		}
	}
	if (i + 1 < m_Row)
	{
		if (Room2DArray[i + 1][j].isTicked == 1)
		{
			counter++;
		}
	}
	if (counter == m_lowestSurroundCount)
	{
		if (Room2DArray[i][j].isTicked == 0)
		{
			m_point += m_lowestSurroundCount;
			Room2DArray[i][j].isTicked = 1;
			m_roomallocationcount--;
			informNeighbours(i, j);
		}
	}
}
void RoomContainer::displayPoint()
{
	cout << "->" << m_point << endl;
}
int main()
{
	int Row, Column, allocationCount;
	fstream file;
	string filename;
	filename = "inputdatafile.txt";
	file.open(filename.c_str());
	std::string line;
	while (!file.eof())
	{
		std::getline(file, line);
		Row = std::stoi(line);
		cout << Row << ',';

		std::getline(file, line);
		Column = std::stoi(line);
		cout << Column << ',';

		std::getline(file, line);
		allocationCount = std::stoi(line);
		cout << allocationCount;

		RoomContainer* myroom = new RoomContainer(Row, Column);
		myroom->AllocateRooms(allocationCount);
		myroom->displayPoint();
	}
	while (1);
}

